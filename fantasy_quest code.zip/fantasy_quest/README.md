# Fantasy Quest: Crystal Catcher (SWC3643)

A 2D Pygame arcade game. A wizard catches falling magic crystals and potions with his hat
and dodges dragon fireballs. Survive 60 seconds with lives remaining to win.

## Run
    pip install pygame pillow
    python make_assets.py   # optional: assets/ is already included
    python main.py

## Controls
LEFT/RIGHT or A/D = move | P = pause | R = restart | ESC = menu | L = English/Malay (menus)

## Rules
- Crystal +10, Potion +25 and restores a life
- Missing a crystal or potion = -1 life; fireball hit = -1 life
- Shield orb blocks one fireball; Hourglass adds 5 seconds
- Game ends at 60 seconds or 0 lives; levels get harder every 20 seconds

## Structure
main.py (AssetManager, Player, Item + Crystal/Potion/Fireball/ShieldOrb/Hourglass, Level,
FloatingText, GameManager) | make_assets.py | assets/ (images + .wav)
